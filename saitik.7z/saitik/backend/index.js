
const express = require("express");
const db = require("better-sqlite3")("eee.db");
var cors = require("cors");

const port = 3000;
const app = express();

app.use(cors());
app.use(express.json());

app.post("/reg", (req, res) => {
    // console.log(req.body);
    const users = db.prepare('SELECT * FROM users WHERE login = ? ').get(req.body.login);  

    if ( users != null) {
        res.sendStatus(400) 
    }
    else {
        db.prepare("INSERT INTO users (login, password, role) VALUES (?, ?, ?)").run(req.body.login, req.body.password, "users");
        res.sendStatus(200)
        console.log("Отлично, клиент зарегистрирован");
    }
    res.send()
})

app.post("/auth", (req, res) => {
    const qq = 'SELECT * FROM users WHERE login = ? AND password = ?';
    const users = db.prepare(qq).get(req.body.login, req.body.password);

    if ( users != null) {
        res.send(users.id + "") // берем тут айди пользователя и потом на фронте через localstorage сохраянем и берем для заявок
        console.log("Отлично, пользователь вошел");
    }
    else {
        res.sendStatus(400)
    }

})

app.get("/getUsers/:id", (req, res) => {
    const users = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    res.send(users) 
})

app.post("/app", (req, res) => {

    db.prepare("INSERT INTO application (date, things, breaking, status) VALUES (?, ?, ?, ?)").run(Date.now(), req.body.things, req.body.breaking, "на рассмотрении");
        
    res.send();
})

app.post("/applications", (req, res) =>{
    console.log(req.body)
    const roleU = db.prepare('SELECT * FROM users WHERE role = ?').get(req.body.role);
    if (roleU !== "users") {
        const users = db.prepare('SELECT * FROM application').all()
        res.send(users)
        console.log("данные есть");
    }
    else{
        res.status(400).send()
    }
})

app.post("/updateAppStatus1", (req, res) => {

    db.prepare("UPDATE application SET status = ? WHERE id = ?").run("одобрено", req.body.id);
    res.send();
})

app.post("/updateAppStatus2", (req, res) => {

    db.prepare("UPDATE application SET status = ? WHERE id = ?").run("отклонено", req.body.id);
    res.send();
})

app.listen(port, () => {
    console.log(`запустился сервер ${port}`);
})