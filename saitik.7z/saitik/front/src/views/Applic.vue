<template>
    <div class="container">
        <div class="main" >
            <h1 style="color: black;">Заполните данные для заявки</h1>
            <input type="text" placeholder="название оборудования" v-model="things">
            <input type="text" placeholder="тип неисправности" v-model="breaking">
            <button class="btn" @click="applic">Отправить заявку</button>
        </div>
        <div v-if="userData.role === 'moderator'" class="divMod">
            <RouterLink to="/moders" class="urlMod">Перейти в окно модератора</RouterLink>
        </div>
        <RouterLink to="/ViewAppMyOrder" class="applic">посмотреть свои заявки</RouterLink>
       
    </div>
</template>

<script setup>
import axios from 'axios';
import { ref, onMounted, reactive} from 'vue';
import router from '@/router';

const userData = reactive({});
let things = ref("");
let breaking = ref("");

async function applic() {
    try {
        if (things.value !== "" && breaking.value !== "") {
            await axios.post("http://localhost:3000/app", {
            things: things.value,
            breaking: breaking.value,
            client: localStorage.getItem("user") // запись айдишника пользователя в строку клиента для заявок
        })
            router.push(`/application`).then(() => {
                window.location.reload()
            })
        }
        else {
            alert("не все поля заполнены");
        }
       
    }
    catch (error){
        alert("не те данные или не все поля заполнены")
    }
}

onMounted(async () => {
    try {
        const user = JSON.parse(localStorage.getItem('user'));

        const userId = user;
        // const userId = 1; // Здесь можно подставить нужный ID пользователя
        const response = await axios.get(`http://localhost:3000/getUsers/${userId}`);
        console.log(response);
        if (response.status === 200) {
            userData.login = response.data.login;
            userData.role = response.data.role;
            userData.password = response.data.password;
        } else {
            console.error('Ошибка при получении данных');
        }
    } catch (error) {
        console.error('Произошла ошибка:', error);
    }
    
});
</script>

<style scoped>
.applic{
    text-decoration: none;
    font-size: 30px;
    margin-top: 20px;
    color: rgb(255, 0, 0);
}
.applic:hover{
    color: rgb(0, 136, 255);
    border: 1px solid rgb(0, 64, 255);
    align-items: center;
}
.container{
    margin-top: 250px;
    margin-left: 600px;
    display: flex;
    flex-direction: column;
    background-color: aliceblue;
    width: 700px;
    height: 500px;
    align-items: center;
    justify-content: center;
    text-align: center;
}
.divMod{
    margin-top: 30px;
    display: flex;
    /* margin-left: 130px; */
    box-sizing: border-box;
}
.urlMod{
    border: 1px solid;
    text-decoration: none;
    text-align: center;
    color: rgb(0, 0, 0);
    font-size: 20px;
    padding: 20px;
}

.urlMod:hover{
    color: rgb(0, 89, 255);
}

.main{
    display: flex;
    flex-direction: column;
    gap: 30px;  
    align-items: center;
}
input{
    width: 300px;
    height: 40px;
}
</style>