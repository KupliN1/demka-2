<template>
    <h1 class="moders" style="margin-bottom: 10px; margin-top: 25px; font-size: 50px;">Добро пожаловать, модератор!</h1>
    <h1 class="moders" style="margin-bottom: 50px; font-size: 48px;">Все заявки пользователей:</h1>
    <div>
        <div > 
            <!-- <h1>Gjr</h1> -->
        </div>
        <div v-for="app in applications" class="app">

            <div class="name_app">
                <h1 class="ggg">Название устройства :</h1>
                <h1 class="appw">{{ app.things }}</h1>
            </div>
            <div class="name_breaking">
                <h1 class="ggg">Тип проблемы :</h1>
                <h1  class="appw">{{ app.breaking }}</h1>
            </div>
            <div class="status1">
                <h1 class="appw">{{ app.status }}</h1>
                <button class="btn-status" @click="changeStatus(app.id)">Изменить статус на одобрено</button>
                <button class="btn-status" @click="changeStatusS(app.id)">Изменить статус на отклонено</button>
            </div>

        </div>
    </div>
</template>

<script setup>
import axios from 'axios'
import { ref, onMounted, reactive} from 'vue';
import router from '@/router';

const applications = ref([])
let gey = ref("")


onMounted(() => {
  axios.post('http://localhost:3000/applications', {role: 'moderator'}).then(response => {
    if (response.status == 200) {
      applications.value = response.data
    } else {
      console.error(response.status)
    }
  }).catch(error => {
    console.error(error)
  })
})

async function changeStatus(id) {

    await axios.post('http://localhost:3000/updateAppStatus1', {id: id})
    location.reload()
  
}

async function changeStatusS(id) {

await axios.post('http://localhost:3000/updateAppStatus2', {id: id})
location.reload()

}

</script>

<style scoped>
.moders{
    text-align: center;
    
}
.status1{
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    justify-content: end;
}

h1{
    color: rgb(255, 255, 255);
}
.app{
    align-items: center;
    justify-content: center;
    display: flex;
    gap: 100px;
}

.name_app, .name_breaking{
    padding: 15px;
    border: 2px solid #00a6ff;
    text-align: left;
    display: flex;
    justify-content: center;
    flex-direction: column;
}

.appw{
    margin-top: 20px;
}

.btn-status{
    margin-top: 20px;
    margin-left: 55px;
}
</style>