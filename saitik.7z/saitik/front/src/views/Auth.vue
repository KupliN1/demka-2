<template>
    <div class="main">
        <div class="content">
            <h1>Авторизация</h1>
            <input type="text" placeholder="введите логин" v-model="login">
            <input type="text" placeholder="введите пароль" v-model="password">
            <!-- <input type="text" style="display: none;" v-model="role"> -->
            <button @click="auth" >Войти</button>
        </div>
       
    </div>
    
</template>

<script setup>
import axios from 'axios';
import { ref, onMounted} from 'vue';
import router from '@/router';

let login = ref("");
let password = ref("");
let role = ref("")

async function auth(){
    try {
        let req = await axios.post("http://localhost:3000/auth", {
            login: login.value,
            password: password.value
        })
        localStorage.setItem("user", req.data)

        localStorage.getItem("user", req.data)
        router.push(`/application`).then(() => {
            window.location.reload()
        })
       
    }
    catch (error){
        alert("не те данные или не все поля заполнены ")
    }
}
</script>

<style scoped>
input{
    width: 250px;
    height: 30px;
}
button{
    width: 200px;
    height: 50px;
}
.main{
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.content{
    margin-left: 34%;
    padding: 50px;
    width: 500px;
    height: 250px;
    background-color: aliceblue;
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;
    margin-top: 200px;
}

h1{
    color: rgb(0, 0, 0);
}
</style>