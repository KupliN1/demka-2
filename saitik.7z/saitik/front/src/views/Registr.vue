<template>
    <div class="main">
        <div class="h1">
            <h1 class="" style="color: red;">Добро пожаловать в наш сервис</h1>
        </div>
        
        <div class="content">
            <h1>Регистрация</h1>
            <input type="text" placeholder="введите логин" v-model="login" class="inp">
            <input type="text" placeholder="введите пароль" v-model="password" class="inp">
            <button @click="registr" class="btn">регистрация</button>
            <button @click="go" class="btn">Перейти на вход</button>
            <!-- <RouterLink to="/application">dds</RouterLink> -->
        </div>
        
    </div>
    
</template>

<script setup>
import axios from 'axios';
import { ref, onMounted} from 'vue';
import router from '@/router';

let login = ref("");
let password = ref("");

async function registr(){

    try {
        await axios.post("http://localhost:3000/reg", {
            login: login.value,
            password: password.value
        })
        router.push(`/auth`).then(() => {
            window.location.reload()
        })
    }
    catch (error) {
        alert("такой пользователь есть")
    }
}
function go(){
    router.push(`/auth`).then(() => {
            window.location.reload()
    })
}
</script>

<style scoped>
a{
    text-decoration: none;
    color: brown;
}

.h1{
    text-align: center;

}

h1{
    font-size: 48px;
    color: rgb(0, 0, 0)
}

.main {
    display: flex;
    justify-content: center;
    margin-top: 20px;
    flex-direction: column;
}

.content{
    margin-left: 540px;
    padding: 50px;
    width: 700px;
    height: 300px;
    background-color: aliceblue;
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;
    margin-top: 200px;
}

.inp{
    width: 450px;
    font-size: 28px;
    padding: 10px;
}

.btn{
    width: 300px;
}
</style>