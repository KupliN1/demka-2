<template>
    <h1 class="ppp">МОИ ЗАЯВКИ:</h1>
    <div v-for="app in app" class="app">
        <div class="name_app">
                <h1>Название устройства</h1>
                <h1 class="appw">{{ app.things }}</h1>
            </div>
            <div class="name_breaking">
                <h1>Тип проблемы</h1>
                <h1  class="appw">{{ app.breaking }}</h1>
            </div>
            <div class="name_breaking">
                <h1>Статус заявки</h1>
                <h1 class="appw">{{ app.status }}</h1>
            </div>
    </div>
</template>

<script setup>
import axios from 'axios'
import { ref, onMounted, reactive} from 'vue';

let app = ref([])

onMounted (async () => {
    let userId = localStorage.getItem("user");
    // if (userId ===  ) {
        axios.post('http://localhost:3000/applications').then(response => {
        if (response.status == 200) {
            app.value = response.data
        } else {
        console.error(response.status)
        }
    }).catch(error => {
        console.error(error)
    })
    // }
  
})
</script>

<style scoped>
.ppp{
    margin-top: 20px;
    text-align: center;
    margin-bottom: 40px;
}
.app{
    align-items: center;
    justify-content: center;
    display: flex;
    gap: 40px;
}

.name_app, .name_breaking{
    border: 1px solid red;
    padding: 15px;
}

.appw{
    margin-top: 20px;
}
</style>