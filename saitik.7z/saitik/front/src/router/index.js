import { createRouter, createWebHistory } from 'vue-router'
import registr from "@/views/Registr.vue"
import auth from "@/views/Auth.vue"
import application from "@/views/Applic.vue"
import moders from "@/views/Moders.vue"
import ViewAppMyOrder from "@/views/ViewApp.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {path: "/", component: registr},
    {path: "/auth", component: auth},
    {path: "/application", component: application},
    {path: "/moders", component: moders},
    {path: "/ViewAppMyOrder", component: ViewAppMyOrder},
  ]
})

export default router
